//
//  ViewController.h
//  BigImgShow
//
//  Created by mac on 3/5/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

