//
//  Comment.m
//  MomentKit
//
//  Created by ZJ on 2017/12/12.
//  Copyright © 2017年 LEA. All rights reserved.
//

#import "Comment.h"

@implementation Comment

+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"id":@"ID"};
}

@end
